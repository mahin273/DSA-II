#include <iostream>
using namespace std;

struct Node {
  int data;
  Node* prev;
  Node* next;
  Node(int data) {
    this->data = data;
    prev = nullptr;
    next = nullptr;
  }
};

// Function to insert a new node at the beginning
Node* insertAtBeginning(Node*& head, int data) {
  Node* newNode = new Node(data);
  newNode->next = head;
  if (head != nullptr) {
    head->prev = newNode;
  }
  head = newNode;
  return newNode;
}

// Function to delete a specified node
void deleteNode(Node*& head, Node* del) {
  if (head == nullptr || del == nullptr) {
    return;
  }

  if (head == del) {
    head = del->next;
  }

  if (del->next != nullptr) {
    del->next->prev = del->prev;
  }

  if (del->prev != nullptr) {
    del->prev->next = del->next;
  }

  delete del;
}

// Function to search for a given value
Node* search(Node* head, int data) {
  Node* current = head;
  while (current != nullptr) {
    if (current->data == data) {
      return current;
    }
    current = current->next;
  }
  return nullptr;
}

// Function to traverse and print the elements
void printList(Node* head) {
  Node* current = head;
  cout << "Doubly Linked List: ";
  while (current != nullptr) {
    cout << current->data << " ";
    current = current->next;
  }
  cout << endl;
}

// Function to count the number of nodes
int getSize(Node* head) {
  int count = 0;
  Node* current = head;
  while (current != nullptr) {
    count++;
    current = current->next;
  }
  return count;
}

int main() {
  Node* head = nullptr;
  int choice, data;

  do {
    cout << "\n1. Insert at Beginning" << endl;
    cout << "2. Delete" << endl;
    cout << "3. Search" << endl;
    cout << "4. Print List" << endl;
    cout << "5. Get Size" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
      case 1:
        cout << "Enter data to insert: ";
        cin >> data;
        insertAtBeginning(head, data);
        break;
      case 2:
        cout << "Enter data to delete: ";
        cin >> data;
        deleteNode(head, search(head, data));
        break;
      case 3:
        cout << "Enter data to search: ";
        cin >> data;
        if (search(head, data) != nullptr) {
          cout << "Data found!" << endl;
        } else {
          cout << "Data not found." << endl;
        }
        break;
      case 4:
        printList(head);
        break;
      case 5:
        cout << "List size: " << getSize(head) << endl;
        break;
      case 0:
        cout << "Exiting..." << endl;
        break;
      default:
        cout << "Invalid choice." << endl;
    }
  } while (choice != 0);

  return 0;
}